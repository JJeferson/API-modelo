const express = require('express');
const router  = express.Router();
const mysql   = require('../mysql').pool;

//lista tudo
router.get('/',(req, res, next) => {
      /*
      res.status(200).send({
             mensagem:'rota produtos respondendo o GET  '

      });
     */ 
    mysql.getConnection((error,conn) =>{
    if (error) {return res.status(500).send({error:error})}
       
       conn.query(
            'select * from produtos',
            (error,resultado,fields) =>{
               
               if (error) {return res.status(500).send({error:error})}
            
                return res.status(200).send({response: resultado})

            }

       )


  })



});
//---------------------------------------------------------------------------------------------

//get num produto especifico
/*
Isso da pra usar para fazer update ou delete.
vcs roda o processo e depois pega uma resposta
*/
router.get('/:id_produto',(req, res, next) => {
 
mysql.getConnection((error,conn) =>{
if (error) {return res.status(500).send({error:error})}
   
   conn.query(
        'select * from produtos where id_produto = ?; ',
        [req.params.id_produto],
        (error,resultado,fields) =>{
           
           if (error) {return res.status(500).send({error:error})}
        
            return res.status(200).send({response: resultado})

        }

   )


})

});
//-------------------------------------------------------------------
//Alteração o Update

router.patch('/',(req, res, next) => {
   
/*
{ 
"id_produto":2,	
"nome":"gerald",
"preco":999999
}
*/
 
//aqui faz o update
mysql.getConnection((error,conn) =>{
    conn.query(
       `update produtos 
        set nome             =? ,
            preco            =? 
            where id_produto =?`,
       [req.body.nome, req.body.preco,req.body.id_produto],
       (error, resultado, field) =>{
             conn.release(); //serve para resetar o pull para não travar

              if (error){
                  return res.status(500).send({
                    error:error,
                    response:null


                  });  
                  
              }

              res.status(201).send({
                    mensagem:'Produto alterado',
                    mensagem:'Alteração concluida no banco de dados',
                   

              });

       }
     
    )
})
 
});

//-------------------------------------------------------------------

router.delete('/',(req, res, next) => {
   
  /*
  { 
  "id_produto":2
  }
  */
   
  //aqui faz o update
  mysql.getConnection((error,conn) =>{
      conn.query(
         `delete from produtos where id_produto=?`,
         [req.body.id_produto],
         (error, resultado, field) =>{
               conn.release(); //serve para resetar o pull para não travar
  
                if (error){
                    return res.status(500).send({
                      error:error,
                      response:null
  
  
                    });  
                    
                }
  
                res.status(201).send({
                      mensagem:'Produto Apagado',
                      mensagem:'Exclusão concluida no banco de dados',
                     
  
                });
  
         }
       
      )
  })
   
  });
  
  

//-------------------------------------------------------------------

//post gravação
router.post('/',(req, res, next) => {
    
      //if (error) {return res.status(500).send({error:error})}

       //recebe o post e grava dentro da variavel produtos
    const produto = {
          nome : req.body.nome,
          preco: req.body.preco

         /*
         Instruções:
         Json a informar no post para inserir:
         Isso no postman
         {
           "nome":"test",
           "preco":12.24
         }

         O create Table:
         create table produtos (
       id_produto int not null PRIMARY KEY AUTO_INCREMENT,
       nome    varchar(50)  not null,
       preco   varchar(100) not null)
         
         */




    }
    //aqui faz o insert
    mysql.getConnection((error,conn) =>{
        conn.query(
           'insert into produtos (nome,preco) values (?,?)',
           [req.body.nome, req.body.preco],
           (error, resultado, field) =>{
                 conn.release(); //serve para resetar o pull para não travar

                  if (error){
                      return res.status(500).send({
                        error:error,
                        response:null
  

                      });  
                      
                  }

                  res.status(201).send({
                        mensagem:'Insere Produto',
                        mensagem:'Produto cadastrado no banco de dados',
                        produtoCriado: produto

                  });

           }
         
        )
    })
    /*
       res.status(201).send({
           mensagem:'Insere Produto',
           produtoCriado: produto

    });
    */


});

module.exports = router;