const express = require('express');
const router = express.Router();
const mysql   = require('../mysql').pool;

router.get('/',(req, res, next) => {
     /*
       res.status(200).send({
             mensagem:'rota pedidos respondendo o GET  '

      });
      */

     mysql.getConnection((error,conn) =>{
       if (error) {return res.status(500).send({error:error})}
          
          conn.query(
               'select * from pedidos',
               (error,resultado,fields) =>{
                  
                  if (error) {return res.status(500).send({error:error})}
               
                   return res.status(200).send({response: resultado})
   
               }
   
          )
   
   
     })

});

//----------------------------------------------------------------------------------------------------
router.get('/:id_pedido',(req, res, next) => {
 
      mysql.getConnection((error,conn) =>{
      if (error) {return res.status(500).send({error:error})}
         
         conn.query(
              'select * from pedidos where id_pedido = ?; ',
              [req.params.id_pedido],
              (error,resultado,fields) =>{
                 
                 if (error) {return res.status(500).send({error:error})}
              
                  return res.status(200).send({response: resultado})
      
              }
      
         )
      
      
      })
      
      });

//----------------------------------------------------------------------------------------------------
//Alteração o Update

router.patch('/',(req, res, next) => {
   
      /*
      { 
      "id_pedido":2,     
      "id_produto":2,	
      "quantidade":999999
      }
      */
       
      //aqui faz o update
      mysql.getConnection((error,conn) =>{
          conn.query(
             `update pedidos 
              set id_produto            =? ,
                  quantidade            =? 
                  where id_pedido       =?`,
             [req.body.id_produto, req.body.quantidade,req.body.id_pedido],
             (error, resultado, field) =>{
                   conn.release(); //serve para resetar o pull para não travar
      
                    if (error){
                        return res.status(500).send({
                          error:error,
                          response:null
      
      
                        });  
                        
                    }
      
                    res.status(201).send({
                          mensagem:'Pedido alterado',
                          mensagem:'Alteração concluida no banco de dados',
                         
      
                    });
      
             }
           
          )
      })
       
      });
      
//----------------------------------------------------------------------------------------------------


router.delete('/',(req, res, next) => {
   
      /*
      { 
      "id_pedido":2
      }
      */
       
      //aqui faz o update
      mysql.getConnection((error,conn) =>{
          conn.query(
             `delete from pedidos where id_pedido=?`,
             [req.body.id_pedido],
             (error, resultado, field) =>{
                   conn.release(); //serve para resetar o pull para não travar
      
                    if (error){
                        return res.status(500).send({
                          error:error,
                          response:null
      
      
                        });  
                        
                    }
      
                    res.status(201).send({
                          mensagem:'Pedido Apagado',
                          mensagem:'Exclusão concluida no banco de dados',
                         
      
                    });
      
             }
           
          )
      })
       
      });
  
      

//----------------------------------------------------------------------------------------------------
router.post('/',(req, res, next) => {

       //recebe o post e grava dentro da variavel pedidos
       const pedidos = {
              id_produto : req.body.id_produto,
              quantidade: req.body.quantidade

               /*
         Instruções:
         Json a informar no post para inserir:
         Isso no postman
         {
           "id_produto": 123,
           "quantidade": 12
         }

         O create Table:
         create table pedidos (
         id_pedido int not null PRIMARY KEY AUTO_INCREMENT,
         id_produto    varchar(50)  not null,
         quantidade    varchar(100) not null)
         
         */



    
        }
    
        mysql.getConnection((error,conn) =>{
              conn.query(
                 'insert into pedidos (id_produto,quantidade) values (?,?)',
                 [req.body.id_produto, req.body.quantidade],
                 (error, resultado, field) =>{
                       conn.release(); //serve para resetar o pull para não travar
      
                        if (error){
                            return res.status(500).send({
                              error:error,
                              response:null
        
      
                            });  
                            
                        }
      
                        res.status(201).send({
                              mensagem:'Insere Pedidos: ',
                              mensagem:'Pedido cadastrado no banco de dados',
                              pedidoCriado: pedidos
      
                        });
      
                 }
               
              )
          })
    /*    
    res.status(201).send({
           mensagem:'rota pedidos  respondendo o post',
           pedidoCriado: pedido
    });
    */

});

module.exports = router;